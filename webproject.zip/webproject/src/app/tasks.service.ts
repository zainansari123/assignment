import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TasksService {

  constructor(private http:HttpClient) { }
  baseurl:string='http://127.0.0.1:8000/'


  gettask(task_id:number){
    console.log('api called');
    return this.http.get(this.baseurl+`task_api/tasks/?task_id=${task_id}`);
  }
  create_new_task(data:any){
    return this.http.post(this.baseurl+'task_api/tasks/',data)
  }
}

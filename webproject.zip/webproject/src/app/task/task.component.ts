import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { TasksService } from '../tasks.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  @ViewChild('taskName') taskName!: ElementRef;
  @ViewChild('taskDescription') taskDescription!: ElementRef;

  constructor(public api: TasksService) {}

  ngOnInit(): void {
    let task_id=1;
    this.api.gettask(task_id).subscribe({
      next: (res: any) => console.log(res),
      error: (err: any) => console.log(err)
    });
  }

  create() {
    let data = {
      'task_name': this.taskName.nativeElement.value, 
      'task_description': this.taskDescription.nativeElement.value
    };

    console.log(data);

    this.api.create_new_task(data).subscribe({
      next: (res: any) => console.log(res),
      error: (err: any) => console.log(err)
    });
  }
}
